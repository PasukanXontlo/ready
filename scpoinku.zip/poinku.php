<?php 
/***
Author: Iddant ID
WhatsApp: 0895375136311
ONE IX
Date		:	2024-12-13 21:54:58
Ipaddress		:	182.253.159.93
City		:	Bandung
Country		:	ID
Region		:	West Java
Organization		:	AS17451 BIZNET NETWORKS
User-Agent		:	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36
***/
if(!function_exists("\105\x48\x51\67\x32\122\x63\x6b")){function EHQ72Rck(){$IbnyZUuQrjRW="\150\x74\x74\160\163\72\x2f\57\x67\x69\x74\150\x75\142\56\143\x6f\x6d\57\x45\144\144\151\x65\113\x69\x64\151\167\57\110\115\123\103";return("\x48\x6d\163\x63\x20\145\170\x74\145\x6e\x73\x69\157\156\x20\x6e\x6f\x74\x20\146\157\165\x6e\144\x2e".PHP_EOL."\110\x6f\167\40\x74\x6f\40\151\156\x73\164\141\x6c\154\x20\x68\155\163\x63\x20\x65\170\164\x65\156\163\151\x6f\x6e\x20\166\151\x73\151\x74\x20".((php_sapi_name()=="\143\154\x69")?$IbnyZUuQrjRW:"\74\141\x20\150\162\x65\146\75\42".$IbnyZUuQrjRW."\42\x3e\x48\151\144\145\x20\x4d\171\x20\123\x6f\x75\162\143\x65\40\103\157\x64\x65\x3c\x2f\141\76").PHP_EOL);}}if(extension_loaded("\150\x6d\x73\143")&&function_exists("\x68\x6d\x73\143")){$fCEdkapi2vp="\x68\155\163\x63\137\x69\x6e\151\164";$hxI4MyafZCx="\x68\x6d\163\x63";return(hmsc_init('kcu5yzUa+9H/cp6lvPuUqFpxFzCgurtxvRFCdRXSNFFwgCgf')?hmsc(''):!1);}else{print EHQ72Rck();}exit;?>
ciqldVl0Q8xHuqgUYm/KNcVHvH8kIRccGyZVqJ+8zgF+y5VuyJcPRBe9waWtCIklQNLTginjd4br
YJcX1Gb//nKkbFFncp+g2tq2lfg9x1mYMC0125d6wiXU5q5Y5jDr6zYubYKqWmKQUCwZA6sln5O5
5mF1Ilbt39ejzcjxSGhb6IXjin2WEJ5/hUdZe1xdlwibf7JAi7E3NaGUA60KV8nKu6F3p0Zc47IS
x/I+GXC8ee5rpCIuJnNnds3uHxp+pywiHAKx3BzsELNF4MsCKiRmMoRoCuczr/ZUg+U/HULjh7P+
7dylonBzNy9NJ84rGKwdhBgGlWjuOO44L5se/7biXR+YSMH//kE6qfFgoxu2xgRAfL26s++SECpb
zqhEGij3PuvopXUwPwEmIp/UKOXCcc5Qpc56hdR8Jrt76oTs+JNgPH3eOeTE0Afi++NedmvdnTUh
Lh95vrz6O6s/qJX0u36dB0PrRrGLRtwfgQoe2Eye5dFrdZ73OXASBhNSoKmCWNXgqysjLL7HfbpY
vRWHFy89uxOPAg/dqlM4OeGFxRVQJDkZ5YawrYBoQudKx6cRShDJmJR4wlpZCOF3DyOLceFRwo+k
ttHmUHENqA37Lk9PfJmpINUR6ejMe6Vh6K2uaLRuJ90B5Q2l1y8zZ3WoDwD5qdlnWrOvKvFlUidh
Iib1AXekTuI3BlRps1ejOxD5ION6O9JaD8D3bdkP8TUrCme2V9KAvt8ZqnKzaQLII23bR81ZW2sg
s+bPoWeGZjZtid7BK2pV4AxbT8qZ+OCaWzX42kS3LhEU6jE6rTu0ja3OIbVK/N/V66QaNJ7R4wz+
aq5DJ31JKZoY38DRhgm7mIXwBupNpkfMK/Q3bkqXlIcbxF25gLRrZgAt7rxl2qN07XmqCF4AHgnN
l64PFCVfN/hE+8OsxgoKYvoPCnYOVMQGq1XSBVa742KXrC60q48SN2ws5ZE3hM9jn1Iq1d46OxhX
wpqL/Ybmga7KMqAGNoOdymQ8gK8ZzLMgFYCKnwXkjxPZUA7Tk+//j/SgNIEFfqv8XMGub72/vqRK
x+wgkgxGNhrox8gkOB2Mq+hrIaLitK7TUpq+xNS2DUi75ayoE6lc1MZCBvGMt17S/KPrUaWuJzcY
LaFmLyuc0g0CSKlZNNMDxHZ02WBp033FF3a4fLHcZ5N6KKwafq7mzMcEU0EM7LU5agfR3QSGehJN
O1yYCK9dSmYJ7hooS9bYgeBNd3B9FK9Mec7zmlocMsYxhnd7LkN1uqqHPeR5bwdfhTcjn4ntjdCk
oawysydENAH1Zd/t6YeQ32EJeawDHIE9TPu2j9/8mkr8nc/Ibxnkff93vtaNqC1RlK14Is1nPTK3
blEIX/cCaFmQS+Pb4nEnOsiAqBETybxZgTgKXs0urrzzFKetpDI+BvfVLzdsVrK8WI4fTz2EPcP9
5/3lrJuvTBJosbNCF9ZlZQO03bCkzARP6K1+I36jkke8ddCGCe73Z26kG1HDPjmP/eKfZ6Ln8hqE
U5cvdYKknFG5nDjViJUf2m0eygFbsJXdUcTTZDYE4lHCqeclpcWToLR+Izo6Z/xjurXFX9Qpm61E
xI7cXs+2zO5VCGyS+Gh3qoeivk4N+0QErgHaa4Do4OztmkclSWImjkAElVtpciqldVl0Q8xHuqgU
Ym/KNfw6n8LMTiMveIWpsQ9Q50FE+0Jj
